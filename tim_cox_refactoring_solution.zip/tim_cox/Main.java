
package tim_cox;

//
// From the terminal:
// $ javac tim_cox/*.java && java tim_cox/Main.java
//
// (Running in IntelliJ seems to prohibit you from reading from the keyboard)
//

public class Main {

    private static final boolean SIMULATOR = true;

    public static final int DISPLAY_WIDTH = 16;
    public static final int DISPLAY_HEIGHT = 2;

    private static Display display;
    private static Menu menu;
    private static InputDevice inputDevice;

    @SuppressWarnings("InfiniteLoopStatement")
    public static void main(String[] args) {
        setup();
        while (true) {
            loop();
        }
    }

    private static void setup() {
        display = DisplayFactory.create(SIMULATOR);
        display.begin(DISPLAY_WIDTH, DISPLAY_HEIGHT);
        display.createChar(Glyphs.UP_ARROW_INDEX, Glyphs.UP_ARROW);
        display.createChar(Glyphs.DOWN_ARROW_INDEX, Glyphs.DOWN_ARROW);

        inputDevice = InputDeviceFactory.create(SIMULATOR);

        menu = new Menu(
                display,
                "START CAPTURE",
                "START SHOWCASE" ,
                "PRESETS",
                "SET TRIGGER",
                "SETTINGS",
                "ABOUT"
        );

        menu.draw();
        display.render();
    }

    private static void loop() {
        boolean render = false;

        final InputDeviceStatus input = inputDevice.poll();

        if (input != InputDeviceStatus.NONE) {
            render = true;
        }

        if (input == InputDeviceStatus.UP) {
            menu.up();
        }

        if (input == InputDeviceStatus.DOWN) {
            menu.down();
        }

        if (render) {
            menu.draw();
            display.render();
        }

    }

}