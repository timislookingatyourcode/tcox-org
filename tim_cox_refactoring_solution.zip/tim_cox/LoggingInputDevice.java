package tim_cox;

public class LoggingInputDevice implements InputDevice {

    private final Log log = new Log("input");
    private final InputDevice backing;

    public LoggingInputDevice(InputDevice backing) {
        Preconditions.checkNotNull(backing, "backing");
        this.backing = backing;
    }

    @Override
    public InputDeviceStatus poll() {
        log.info("polling");
        final InputDeviceStatus status = backing.poll();
        log.info("poll returned " + status);
        return status;
    }
}
