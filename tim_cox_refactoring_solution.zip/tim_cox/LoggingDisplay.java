package tim_cox;

public class LoggingDisplay implements Display {

    private final Display backing;
    private final Log log = new Log("display");

    public LoggingDisplay(Display aBacking) {
        this.backing = aBacking;
    }

    @Override
    public void clear() {
        log.info("clear");
        backing.clear();
    }

    @Override
    public void begin(int cols, int rows) {
        log.info("begin " + cols + " " + rows);
        backing.begin(cols, rows);
    }

    @Override
    public void setCursor(int col, int row) {
        log.info("set cursor " + col + " " + row);
        backing.setCursor(col, row);
    }

    @Override
    public void print(String text) {
        log.info("print " + text);
        backing.print(text);
    }

    @Override
    public void write(char value) {
        log.info("write " + (int) value);
        backing.write(value);
    }

    @Override
    public void createChar(char number, Glyph data) {
        log.info("createChar " + number + " " + data);
        backing.createChar(number, data);
    }

    @Override
    public int width() {
        final int width = backing.width();
        log.info("width returning " + width);
        return width;
    }

    @Override
    public int height() {
        final int height = backing.height();
        log.info("height returning " + height);
        return height;
    }

    @Override
    public void render() {
        log.info("render");
        backing.render();
    }

}
