package tim_cox;

public class Log {

    private final String prefix;

    Log(String prefix) {
        Preconditions.checkNotNull(prefix, "prefix");
        this.prefix = prefix;
    }

    void info(String message) {
        System.out.println(prefix + ": " + message);
    }

}
