package tim_cox;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class SimulatedDisplay implements Display {

    private final Map<Character, Glyph> charset = new HashMap<Character, Glyph>();
    private char[][] /* [row][column] */ grid = null; // begin must be called to initialize
    private int cursorRow = 0;
    private int cursorColumn = 0;

    SimulatedDisplay() {
        charset.put('A', Glyphs.A);
        charset.put('B', Glyphs.B);
        charset.put('C', Glyphs.C);
        charset.put('D', Glyphs.D);
        charset.put('E', Glyphs.E);
        charset.put('F', Glyphs.F);
        charset.put('G', Glyphs.G);
        charset.put('H', Glyphs.H);
        charset.put('I', Glyphs.I);
        charset.put('J', Glyphs.J);
        charset.put('K', Glyphs.K);
        charset.put('L', Glyphs.L);
        charset.put('M', Glyphs.M);
        charset.put('N', Glyphs.N);
        charset.put('O', Glyphs.O);
        charset.put('P', Glyphs.P);
        charset.put('Q', Glyphs.Q);
        charset.put('R', Glyphs.R);
        charset.put('S', Glyphs.S);
        charset.put('T', Glyphs.T);
        charset.put('U', Glyphs.U);
        charset.put('V', Glyphs.V);
        charset.put('W', Glyphs.W);
        charset.put('X', Glyphs.X);
        charset.put('Y', Glyphs.Y);
        charset.put('Z', Glyphs.Z);
        charset.put(' ', Glyphs.SPACE);
    }

    @Override
    public void clear() {
        for (char[] ints : grid) {
            Arrays.fill(ints, (char) 0);
        }
    }

    @Override
    public void begin(int cols, int rows) {
        this.grid = new char[rows][cols];
        cursorColumn = 0;
        cursorRow = 0;
    }

    @Override
    public void setCursor(int col, int row) {
        cursorColumn = col;
        cursorRow = row;
    }

    @Override
    public void print(String text) {
        for (char ch : text.toCharArray()) {
            grid[cursorRow][cursorColumn] = ch;
            cursorColumn++;
            if (cursorColumn >= grid[0].length) {
                return;
            }
        }
    }

    @Override
    public void write(char value) {
        grid[cursorRow][cursorColumn] = value;
    }

    @Override
    public void createChar(char ch, Glyph data) {
        charset.put(ch, data);
    }

    @Override
    public int width() {
        Preconditions.checkNotNull(grid, "screen must have been initialized by begin()");
        return grid[0].length;
    }

    @Override
    public int height() {
        Preconditions.checkNotNull(grid, "screen must have been initialized by begin()");
        return grid.length;
    }

    @Override
    public void render() {
        for (char[] row : grid) {
            renderRow(row);
            System.out.println();
        }
    }

    private void renderRow(char[] row) {
        for (int y = 0; y < Glyph.HEIGHT; y++) {
            for (char ch : row) {
                Glyph glyph = charset.get(ch);
                if (glyph == null) {
                    glyph = Glyphs.SPACE;
                }
                System.out.print(" " + glyph.line(y) + " ");
            }
            System.out.println();
        }
    }

}
