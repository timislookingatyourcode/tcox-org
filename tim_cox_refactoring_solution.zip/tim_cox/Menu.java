package tim_cox;

import java.util.Arrays;

public class Menu {

    private final String[] options;
    private final Display display;

    // index of the uppermost _visible_ option
    private int scroll = 0;

    public Menu(Display display, String... options) {
        Preconditions.checkNotNull(options, "options");
        this.options = Arrays.copyOf(options, options.length);
        if (this.options.length < 1) {
            throw new IllegalArgumentException("options must contain at least one option");
        }
        Preconditions.checkNotNull(display, "display");
        this.display = display;
    }

    public void draw() {
        display.clear();
        final int height = display.height();
        for (int row = 0; row < height; row++) {
            int index = scroll + row;
            if (index >= this.options.length) {
                index = this.options.length - 1;
            }
            if (index < 0) {
                index = 0;
            }
            final String option = options[index];
            display.setCursor(0, row);
            display.print(option);
        }

        if (this.scroll > 0) {
            // user can scroll up
            display.setCursor(display.width() - 1, 0); // top right
            display.write(Glyphs.UP_ARROW_INDEX);
        }

        if (this.scroll + height < this.options.length) {
            display.setCursor(display.width() - 1, height - 1); // bottom right
            display.write(Glyphs.DOWN_ARROW_INDEX);
        }

    }

    public void up() {
        scroll--;
        if (scroll < 0) {
            scroll = 0;
        }
    }

    public void down() {
        scroll++;
        // e.g. 4 options, 2 line screen, max is:
        // 4 - 2
        // top row is index 2
        // lower row is index 3 (last option)
        final int max = options.length - display.height();
        if (scroll > max) {
            scroll = max;
        }
    }
}
