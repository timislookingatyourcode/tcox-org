package tim_cox;

public enum Pin {

    Register_Select_Pin(8),

    Enable_Pin(9),

    Data_4_Pin(4),
    Data_5_Pin(5),
    Data_6_Pin(6),
    Data_7_Pin(7),

    Analog_1_Pin(1)

    ;

    private final int number;

    Pin(int number) {
        this.number = number;
    }
}
