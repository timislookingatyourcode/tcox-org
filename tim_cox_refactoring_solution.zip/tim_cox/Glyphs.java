package tim_cox;

public class Glyphs {

    // Avoiding zero index, because a blank screen raster is all zeroes

    static final char DOWN_ARROW_INDEX = 1;
    public static final Glyph DOWN_ARROW = new Glyph(
            "  #  ", // 1
            "  #  ", // 2
            "  #  ", // 3
            "  #  ", // 4
            "  #  ", // 5
            "#####", // 6
            " ### ", // 7
            "  #  " // 8
    );

    static final char UP_ARROW_INDEX = 2;
    public static final Glyph UP_ARROW = DOWN_ARROW.flipVertically();

    public static final Glyph A = new Glyph(
            " ### ", // 1
            "#   #", // 2
            "#   #", // 3
            "#####", // 4
            "#   #", // 5
            "#   #", // 6
            "#   #", // 7
            "#   #" // 8
    );

    public static final Glyph SPACE = new Glyph(
            "     ", // 1
            "     ", // 2
            "     ", // 3
            "     ", // 4
            "     ", // 5
            "     ", // 6
            "     ", // 7
            "     " // 8
    );

    public static final Glyph B = new Glyph(
            "#### ", // 1
            "#   #", // 2
            "#   #", // 3
            "#### ", // 4
            "#   #", // 5
            "#   #", // 6
            "#   #", // 7
            "#### " // 8
    );

    public static final Glyph C = new Glyph(
            " ####", // 1
            "#    ", // 2
            "#    ", // 3
            "#    ", // 4
            "#    ", // 5
            "#    ", // 6
            "#    ", // 7
            " ####" // 8
    );

    public static final Glyph D = new Glyph(
            "#### ", // 1
            "#   #", // 2
            "#   #", // 3
            "#   #", // 4
            "#   #", // 5
            "#   #", // 6
            "#   #", // 7
            "#### " // 8
    );

    public static final Glyph E = new Glyph(
            "#####", // 1
            "#    ", // 2
            "#    ", // 3
            "#####", // 4
            "#    ", // 5
            "#    ", // 6
            "#    ", // 7
            "#####" // 8
    );

    public static final Glyph F = new Glyph(
            "#####", // 1
            "#    ", // 2
            "#    ", // 3
            "#####", // 4
            "#    ", // 5
            "#    ", // 6
            "#    ", // 7
            "#    " // 8
    );

    public static final Glyph G = new Glyph(
            " ####", // 1
            "#    ", // 2
            "#    ", // 3
            "#    ", // 4
            "#  # ", // 5
            "#   #", // 6
            "#   #", // 7
            "#### " // 8
    );

    public static final Glyph H = new Glyph(
            "#   #", // 1
            "#   #", // 2
            "#   #", // 3
            "#   #", // 4
            "#####", // 5
            "#   #", // 6
            "#   #", // 7
            "#   #" // 8
    );

    public static final Glyph I = new Glyph(
            "#####", // 1
            "  #  ", // 2
            "  #  ", // 3
            "  #  ", // 4
            "  #  ", // 5
            "  #  ", // 6
            "  #  ", // 7
            "#####" // 8
    );

    public static final Glyph J = new Glyph(
            "    #", // 1
            "    #", // 2
            "    #", // 3
            "    #", // 4
            "    #", // 5
            "    #", // 6
            "    #", // 7
            "#### " // 8
    );

    public static final Glyph K = new Glyph(
            "#    ", // 1
            "#  # ", // 2
            "# #  ", // 3
            "##   ", // 4
            "##   ", // 5
            "# #  ", // 6
            "#  # ", // 7
            "#    " // 8
    );

    public static final Glyph L = new Glyph(
            "#    ", // 1
            "#    ", // 2
            "#    ", // 3
            "#    ", // 4
            "#    ", // 5
            "#    ", // 6
            "#    ", // 7
            " ####" // 8
    );

    public static final Glyph M = new Glyph(
            "## ##", // 1
            "# # #", // 2
            "# # #", // 3
            "#   #", // 4
            "#   #", // 5
            "#   #", // 6
            "#   #", // 7
            "#   #" // 8
    );

    public static final Glyph N = new Glyph(
            "#   #", // 1
            "#   #", // 2
            "##  #", // 3
            "# # #", // 4
            "#  ##", // 5
            "#   #", // 6
            "#   #", // 7
            "#   #" // 8
    );

    public static final Glyph O = new Glyph(
            " ### ", // 1
            "#   #", // 2
            "#   #", // 3
            "#   #", // 4
            "#   #", // 5
            "#   #", // 6
            "#   #", // 7
            " ### " // 8
    );

    public static final Glyph P = new Glyph(
            " ### ", // 1
            "#   #", // 2
            "#   #", // 3
            "#   #", // 4
            "#### ", // 5
            "#    ", // 6
            "#    ", // 7
            "#    " // 8
    );

    public static final Glyph Q = new Glyph(
            " ### ", // 1
            "#   #", // 2
            "#   #", // 3
            "#   #", // 4
            "#   #", // 5
            "# # #", // 6
            "#  ##", // 7
            "#####" // 8
    );

    public static final Glyph R = new Glyph(
            " ### ", // 1
            "#   #", // 2
            "#   #", // 3
            "#### ", // 4
            "##   ", // 5
            "# #  ", // 6
            "#  # ", // 7
            "#   #" // 8
    );

    public static final Glyph S = new Glyph(
            " ####", // 1
            "#    ", // 2
            "#    ", // 3
            "#### ", // 4
            "    #", // 5
            "    #", // 6
            "    #", // 7
            "#### " // 8
    );

    public static final Glyph T = new Glyph(
            "#####", // 1
            "  #  ", // 2
            "  #  ", // 3
            "  #  ", // 4
            "  #  ", // 5
            "  #  ", // 6
            "  #  ", // 7
            "  #  " // 8
    );

    public static final Glyph U = new Glyph(
            "#   #", // 1
            "#   #", // 2
            "#   #", // 3
            "#   #", // 4
            "#   #", // 5
            "#   #", // 6
            "#   #", // 7
            " ### " // 8
    );

    public static final Glyph V = new Glyph(
            "#   #", // 1
            "#   #", // 2
            "#   #", // 3
            "#   #", // 4
            "#   #", // 5
            "#   #", // 6
            " # # ", // 7
            "  #  " // 8
    );


    public static final Glyph W = new Glyph(
            "#   #", // 1
            "#   #", // 2
            "#   #", // 3
            "#   #", // 4
            "# # #", // 5
            "# # #", // 6
            "# # #", // 7
            " # # " // 8
    );

    public static final Glyph X = new Glyph(
            "#   #", // 1
            " # # ", // 2
            " # # ", // 3
            "  #  ", // 4
            " # # ", // 5
            " # # ", // 6
            " # # ", // 7
            "#   #" // 8
    );


    public static final Glyph Y = new Glyph(
            "#   #", // 1
            "#   #", // 2
            "#   #", // 3
            " # # ", // 4
            "  #  ", // 5
            "  #  ", // 6
            "  #  ", // 7
            "  #  " // 8
    );

    public static final Glyph Z = new Glyph(
            "#####", // 1
            "    #", // 2
            "    #", // 3
            "   # ", // 4
            "  #  ", // 5
            " #   ", // 6
            "#    ", // 7
            "#####" // 8
    );


}
