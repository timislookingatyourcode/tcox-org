package tim_cox;

import java.io.*;

public class SimulatedInputDevice implements InputDevice {

    private final Console console;

    public SimulatedInputDevice() {
        console = System.console();
        Preconditions.checkNotNull(console, "This must be run in an interactive terminal");
    }

    public InputDeviceStatus poll() {
        System.out.print("Press [P] for up, [L] for down, then hit [Enter]: ");
        final String line = console.readLine();
        if (line == null || line.isBlank()) {
            return InputDeviceStatus.NONE;
        }
        if (line.equalsIgnoreCase("P")) {
            return InputDeviceStatus.UP;
        }
        if (line.equalsIgnoreCase("L")) {
            return InputDeviceStatus.DOWN;
        }
        return InputDeviceStatus.NONE;
    }

}
