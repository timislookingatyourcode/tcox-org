package tim_cox;

public enum InputDeviceStatus {

    UP,

    DOWN,

    NONE

}
