package tim_cox;

public class AnalogInputDevice implements InputDevice {

    private final Pin pin;

    public AnalogInputDevice(Pin pin) {
        this.pin = pin;
    }


    @Override
    public InputDeviceStatus poll() {
        final int reading = readAnalog(pin);
        if (reading < 50) {
            return InputDeviceStatus.UP;
        }
        if (reading < 195) {
            return InputDeviceStatus.DOWN;
        }
        return InputDeviceStatus.NONE;
    }

    private static int readAnalog(Pin pin) {
        // stub
        return -1;
    }
}
