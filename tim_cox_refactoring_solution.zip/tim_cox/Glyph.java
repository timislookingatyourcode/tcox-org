
package tim_cox;

import java.util.ArrayList;
import java.util.List;

// immutable
public class Glyph {

    private static final int WIDTH = 5;
    static final int HEIGHT = 8;

    private final List<String> raster = new ArrayList<>();

    Glyph(String... raster) {
        Preconditions.checkNotNull(raster, "raster");
        Preconditions.checkArgument(raster.length, HEIGHT, "data length must match height");
        for (int i = 0; i < raster.length; i++) {
            Preconditions.checkArgument(raster[i].length(), WIDTH, "data row " + (i+1) + " must match width");
            this.raster.add(raster[i]);
        }
    }

    Glyph flipVertically() {
        return new Glyph(raster.reversed().toArray(String[]::new));
    }

    @Override
    public String toString() {
        return "[Glyph]";
    }

    public String line(int row) {
        if (row < 0 || row >= raster.size()) {
            throw new IllegalArgumentException("Row out of bounds: " + row);
        }
        return raster.get(row );
    }
}
