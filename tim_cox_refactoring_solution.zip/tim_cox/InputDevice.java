package tim_cox;

public interface InputDevice {

    InputDeviceStatus poll();

}
