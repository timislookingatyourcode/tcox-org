package tim_cox;

public class InputDeviceFactory {

    public static InputDevice create(boolean simulator) {
        return new LoggingInputDevice(internalCreate(simulator));
    }

    private static InputDevice internalCreate(boolean simulator) {
        if (simulator) {
            return new SimulatedInputDevice();
        } else {
            return new AnalogInputDevice(Pin.Analog_1_Pin);
        }
    }

}
