package tim_cox;

public class LiquidCrystalDisplay implements Display {

    private final Pin rs;
    private final Pin enable;
    private final Pin data4;
    private final Pin data5;
    private final Pin data6;
    private final Pin data7;

    // probably these should be named differently
    // they are data4/5/6/7 to the microcontroller,
    // the LCD probably doesn't know them by those names
    LiquidCrystalDisplay(
            Pin rs,
            Pin enable,
            Pin data4,
            Pin data5,
            Pin data6,
            Pin data7
    ) {
        Preconditions.checkNotNull(rs, "rs");
        Preconditions.checkNotNull(enable, "enable");
        Preconditions.checkNotNull(data4, "data4");
        Preconditions.checkNotNull(data5, "data5");
        Preconditions.checkNotNull(data6, "data6");
        Preconditions.checkNotNull(data7, "data7");
        this.rs = rs;
        this.enable = enable;
        this.data4 = data4;
        this.data5 = data5;
        this.data6 = data6;
        this.data7 = data7;
    }

    @Override
    public void clear() {
        // stub
    }

    @Override
    public void begin(int width, int height) {
        // stub
    }

    @Override
    public void setCursor(int col, int row) {
        // stub
    }

    @Override
    public void print(String text) {
        // stub
    }

    @Override
    public void write(char value) {
        // stub
    }

    @Override
    public void createChar(char number, Glyph data) {
        // stub
    }

    @Override
    public int width() {
        // stub
        return -1;
    }

    @Override
    public int height() {
        // stub
        return -1;
    }

    @Override
    public void render() {
        // stub (possibly no-op, unless screen is double-buffered)
    }

}
