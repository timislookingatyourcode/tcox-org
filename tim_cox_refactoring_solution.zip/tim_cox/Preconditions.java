package tim_cox;

public class Preconditions {

    public static void checkNotNull(Object o, String name) {
        if (o == null) {
            throw new IllegalArgumentException("Cannot be null: " + name);
        }
    }

    public static void checkArgument(Object value, Object expected, String description) {
        if (value != expected) {
            throw new IllegalArgumentException(value + " != " + expected + ": " + description);
        }
    }
}
