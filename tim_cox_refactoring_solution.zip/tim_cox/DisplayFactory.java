package tim_cox;

public class DisplayFactory {

    public static Display create(boolean simulator) {
        return new LoggingDisplay(internalCreate(simulator));
    }

    private static Display internalCreate(boolean simulator) {
        if (simulator) {
            return new SimulatedDisplay();
        } else {
            return new LiquidCrystalDisplay(
                    Pin.Register_Select_Pin,
                    Pin.Enable_Pin,
                    Pin.Data_4_Pin,
                    Pin.Data_5_Pin,
                    Pin.Data_6_Pin,
                    Pin.Data_7_Pin
            );
        }
    }

}
