package tim_cox;

public interface Display {

    void clear();

    void begin(int cols, int rows);

    void setCursor(int col, int row);

    void print(String text);

    void write(char value);

    void createChar(char character, Glyph data);

    int width();

    int height();

    void render();
}
